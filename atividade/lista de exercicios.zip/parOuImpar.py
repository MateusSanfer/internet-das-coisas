numerosPares = 0
numerosImpares = 0

for i in range(5):
  numero = int(input('Digite um numero: '))

  if numero % 2 == 0:
    numerosPares += 1
  else:
    numerosImpares += 1
    
print('Números Pares: ', numerosPares)
print('Números Impares: ', numerosImpares)