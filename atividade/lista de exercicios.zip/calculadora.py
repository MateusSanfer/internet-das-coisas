import os
resultado = float
numero1 = int(input("Digite um número: "))
numero2 = int(input('Digite outro número: '))
os.system('clear')

print("[1] - Soma")
print("[2] - Subtração")
print("[3] - Multiplicação")
print('[4] - Divisão')

operecao = int(input("Digite o número da operação desejada: "))
os.system('clear')

if operecao == 1:
  resultado = numero1 + numero2
elif operecao == 2:
  resultado = numero1 - numero2
elif operecao == 3:
  resultado = numero1 * numero2
elif operecao == 4:
  resultado = numero1 / numero2
else:
  print("Operação inválida")
  
print(f"Resultado: {resultado}")