import random
import os

numero = int(input("Digite um número em 1 e 100: "))
os.system('clear')
numeroAleatorio = int(random.randint(1,100))
tentativa = 1

while True:
  
  if numero == numeroAleatorio:
    
    print(f"Parabéns, Você Acertou! O número secreto é: {numeroAleatorio}.")
    break
  
  elif numero > numeroAleatorio:
    print(f"Tentativa {tentativa}: Seu chute foi MAIOR que o número secreto!")
    numero = int(input("Digite o número novamente: "))
    os.system('clear')
    
  else:
    print(f'Tentativa {tentativa}: Seu chute foi MENOR que o número secreto!')
    numero = int(input("Digite o número novamente: "))
    os.system('clear')
    
  tentativa += 1


