tempCelsius = float(input("Diga a temperatura: "))

tempFahrenheit = (tempCelsius * 9 / 5) + 32

print(f" A temperatura de {tempCelsius} °C em Fahrenheit é de: {tempFahrenheit} °F")